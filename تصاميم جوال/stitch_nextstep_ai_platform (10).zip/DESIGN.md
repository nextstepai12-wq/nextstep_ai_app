---
name: Academic Intelligence
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#43474e'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f88'
  primary: '#002045'
  on-primary: '#ffffff'
  primary-container: '#1a365d'
  on-primary-container: '#86a0cd'
  inverse-primary: '#adc7f7'
  secondary: '#004fda'
  on-secondary: '#ffffff'
  secondary-container: '#2b69fd'
  on-secondary-container: '#fefbff'
  tertiary: '#002619'
  on-tertiary: '#ffffff'
  tertiary-container: '#003e2c'
  on-tertiary-container: '#00b485'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#adc7f7'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#2d476f'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b5c4ff'
  on-secondary-fixed: '#00174d'
  on-secondary-fixed-variant: '#003cac'
  tertiary-fixed: '#63fcc4'
  tertiary-fixed-dim: '#3edfaa'
  on-tertiary-fixed: '#002115'
  on-tertiary-fixed-variant: '#00513a'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
  deep-navy: '#173B73'
  surface-gray: '#F9FAFB'
  border-subtle: '#E5E7EB'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

This design system is engineered for a modern academic AI guidance platform. The brand personality is **authoritative yet accessible**, bridging the gap between traditional scholarly excellence and cutting-edge artificial intelligence. It targets students, researchers, and educators who require a tool that feels intellectually serious but technologically advanced.

The visual style is **Corporate Modern with a High-Tech edge**. It prioritizes clarity and logic, utilizing a "systematic" aesthetic that reflects the precision of AI. Key characteristics include:
- **High-Information Density:** Layouts that manage complex data without feeling cluttered.
- **Visual Precision:** Using subtle grid lines and mathematical spacing to evoke a sense of "accuracy."
- **Trustworthy Innovation:** A blend of deep, institutional blues with energetic, digital teals to represent the fusion of academia and future-tech.

## Colors

The palette is anchored by **Deep Blue (#1a365d)**, providing an institutional foundation that communicates reliability and depth. **Secondary Blue (#2F6BFF)** is used for primary actions and highlights, ensuring the interface feels energetic and modern.

**Teal (#48E6B0)** serves as the "AI Signal" color—used sparingly for success states, AI-generated content indicators, and specific data visualizations to represent the platform's high-tech capabilities. The neutral palette utilizes **#1F2937** for high-contrast typography, ensuring maximum legibility against clean white surfaces.

## Typography

The design system exclusively utilizes **Be Vietnam Pro**. This typeface was selected for its contemporary, geometric construction that maintains a warm, humanist feel—essential for an educational context.

- **Headlines:** Use tighter letter-spacing and heavier weights (600-700) to create a strong visual hierarchy.
- **Body Text:** Maintained at 16px for optimal readability in long-form academic content. 
- **Labels:** Small-caps or increased letter-spacing should be applied to `label-md` when used for navigation categories or metadata tags to distinguish them from body copy.

## Layout & Spacing

This design system employs a **Fluid Grid** model based on an 8px scale. The content is contained within a 1280px maximum width for desktop to ensure line lengths remain readable for academic text.

- **Desktop (1024px+):** 12-column grid with 24px gutters and 40px side margins.
- **Tablet (768px - 1023px):** 8-column grid with 20px gutters and 24px side margins.
- **Mobile (Up to 767px):** 4-column grid with 16px gutters and 16px side margins.

Vertical rhythm is maintained through standardized "stacks"—consistent vertical spacing between related elements (12px), sections (24px), and major content blocks (48px).

## Elevation & Depth

To maintain a "High-Tech" feel while ensuring professional stability, this design system uses **Tonal Layering** and **Subtle Glassmorphism**:

- **Surface Tiers:** Backgrounds use `#FFFFFF`, while secondary containers (sidebars, cards) use `surface-gray (#F9FAFB)`.
- **Low-Contrast Outlines:** Instead of heavy shadows, use 1px borders in `border-subtle (#E5E7EB)` to define elements.
- **Interactive Depth:** Only use shadows on active elements like "floating" AI chat bubbles or open dropdowns. Shadows should be ultra-diffused: `0 10px 25px -5px rgba(26, 54, 93, 0.1)`.
- **Glassmorphism:** Use for persistent navigation bars or AI modal overlays—10px backdrop blur with a 70% white opacity fill to maintain context of the underlying academic data.

## Shapes

The shape language is **Rounded (8px base)**. This provides a soft, approachable feel that offsets the potential coldness of the technology.

- **Buttons & Inputs:** Use the standard 8px radius.
- **Large Cards:** Use `rounded-lg` (16px) to house grouped academic modules.
- **AI Feedback Tags:** Use `rounded-xl` (24px) or full pills to distinguish AI-generated suggestions from static data.

## Components

- **Buttons:** Primary buttons use `primary_color_hex` with white text. Secondary buttons use a `border-subtle` outline with `secondary_color_hex` text. Use an 8px radius.
- **AI Guidance Chips:** Small, pill-shaped indicators using a light tint of `tertiary_color_hex` (Teal) with dark teal text to highlight AI insights.
- **Input Fields:** 1px border (`border-subtle`), 8px radius. On focus, the border transitions to `secondary_color_hex` with a subtle 2px glow.
- **Academic Cards:** White background, 1px `border-subtle`, 16px radius. Title in `headline-md` and body in `body-sm`.
- **Lists:** Clean, unbordered lists with 12px vertical padding between items. Use `deep-navy` for bullet points or iconography to maintain institutional feel.
- **Progress Bars:** Use `tertiary_color_hex` for completion states in academic tracks or AI processing indicators.